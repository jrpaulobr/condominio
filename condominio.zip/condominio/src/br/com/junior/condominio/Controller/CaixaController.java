package br.com.junior.condominio.Controller;


import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.CaixaDAO;
import br.com.junior.condominio.models.Caixa;
import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class CaixaController {
	private Result result;

	public CaixaController(Result result) {
		this.result = result;
	}

	public void cadastrar() {
		new Manager();
	}

	// exibe o pagina para atualizar
	public void visualizar() {
		result.include("Caixa", new CaixaDAO().lista());

	}

	public void listar() {
		result.use(Results.json()).withoutRoot().from(new CaixaDAO().lista()).serialize();
	}

	public void consultar(Caixa c) {
		result.use(Results.json()).withoutRoot().from(new CaixaDAO().localiza(c)).serialize();

	}

	public void salvar(Caixa c) {
		try {
			new CaixaDAO().adiciona(c);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Caixa: " + ex);
		}

	}

	public void remover(Caixa c) {
		try {
			new CaixaDAO().remove(c);
			result.use(Results.http()).body("Deletado com Sucesso");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Caixa: " + ex);
		}

	}
}
