package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.UsuariosDAO;

import br.com.junior.condominio.models.Usuarios;

import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class UsuariosController {
	private Result result;

	public UsuariosController(Result result) {
		this.result = result;
	}
	@Path("/usuarios")
	public void cadastrar() {
		//new Manager();
		// result.forwardTo("/WEB-INF/jsp/usuarios/cadastrar.jsp");
	}

	public void listar() {
		new Manager();
		result.use(Results.json()).withoutRoot().from(new UsuariosDAO().lista());
	}

	public void consultar(Usuarios a) {
		//result.use(Results.json()).withoutRoot().from(new UsuariosDAO().localiza(a)).serialize();
		new Manager();
		result.use(Results.json()).withoutRoot().from(new UsuariosDAO().localiza(a));
		
	}

	public void salvar(Usuarios a) {
		try {
			new UsuariosDAO().salvar(a);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Usuarios: " + ex);
		}

	}

	public void remove(Usuarios a) {
		try {
			new UsuariosDAO().remove(a);
			// new UsuariosDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Usuarios: " + ex);
		}

	}
}
