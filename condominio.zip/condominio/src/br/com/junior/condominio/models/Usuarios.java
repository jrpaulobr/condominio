package br.com.junior.condominio.models;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

import com.thoughtworks.xstream.converters.basic.DateConverter;

import br.com.caelum.vraptor.Convert;

@Entity
@Table(name = "usuarios")
public class Usuarios {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
		
	@ManyToOne
	@JoinColumn(name = "id_grupo", nullable = false)
	Grupos grupos;
	
	@Column(name = "login", length = 30, nullable = false)
	private String login;
	
	@Column(name = "senha", length = 30, nullable = false)
	private String senha;
	
	@Temporal(javax.persistence.TemporalType.DATE)
	@Column(name="ult_acesso")
	@Convert(DateConverter.class)
	private Date ult_acesso;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Grupos getGrupos() {
		return grupos;
	}

	public void setGrupos(Grupos grupos) {
		this.grupos = grupos;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public Date getUlt_acesso() {
		return ult_acesso;
	}

	public void setUlt_acesso(Date ult_acesso) {
		this.ult_acesso = ult_acesso;
	}


}
