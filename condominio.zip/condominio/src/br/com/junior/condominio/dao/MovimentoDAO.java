package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.junior.condominio.models.Movimento;
import br.com.junior.condominio.util.Manager;

public class MovimentoDAO {	

	EntityManager manager = Manager.getManager();

	public void salvar(Movimento alias) {	
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();
	}
 
	public void remove(Movimento alias) {
		manager.getTransaction().begin();
		manager.remove(manager.merge(alias));
		manager.getTransaction().commit();

	}

	@SuppressWarnings("unchecked")
	public List<Movimento> lista() {
		Query query = manager.createQuery("select a from Movimento a");
		List<Movimento> list = query.getResultList();
		
		return list;
	}
	
	public Movimento localiza(Movimento alias) {
		return manager.find(Movimento.class, alias.getId());
	}

}
