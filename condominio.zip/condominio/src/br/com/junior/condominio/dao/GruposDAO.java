package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.junior.condominio.models.Grupos;
import br.com.junior.condominio.util.Manager;

public class GruposDAO {	

	EntityManager manager = Manager.getManager();

	public void salvar(Grupos alias) {	
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();
	}
 
	public void remove(Grupos alias) {
		manager.getTransaction().begin();
		manager.remove(manager.merge(alias));
		manager.getTransaction().commit();

	}

	@SuppressWarnings("unchecked")
	public List<Grupos> lista() {
		Query query = manager.createQuery("select a from Grupos a");
		List<Grupos> list = query.getResultList();
		
		return list;
	}
	
	public Grupos localiza(Grupos alias) {
		return manager.find(Grupos.class, alias.getId());
	}

}
