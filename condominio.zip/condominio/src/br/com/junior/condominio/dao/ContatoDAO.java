package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import br.com.junior.condominio.models.Contatos;

public class ContatoDAO {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("condominio");
	EntityManager manager = factory.createEntityManager();

	public void adiciona(Contatos alias) {
		manager.getTransaction().begin();
		manager.persist(alias);
		manager.getTransaction().commit();		
		manager.close();
		factory.close();
	}

	public void atualiza(Contatos alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();		
		manager.close();
		factory.close();
	}

	
	public void remove(Contatos alias) {
		manager.getTransaction().begin();
		 manager.remove(manager.merge(alias));
		manager.getTransaction().commit();		
		manager.close();
		factory.close();
		
	}
	
	@SuppressWarnings("unchecked")
	public List<Contatos> lista() {
		Query query = manager.createQuery("SELECT alias.* from Pessoa alias");
		// seta dados
		List<Contatos> list = query.getResultList();
		manager.close();
		factory.close();
		return list;
	}

	@SuppressWarnings("unchecked")
	public List<Contatos> localiza(Contatos alias) {
		Query query = manager.createQuery("SELECT alias from Pessoa alias where alias.id_pessoa = :id_pessoa");
		// seta dados
		query.setParameter("id_pessoa", alias.getId());
		List<Contatos> list = query.getResultList();
		manager.close();
		factory.close();
		return list;
	}

}
