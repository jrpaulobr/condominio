package br.com.junior.condominio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "contatos")
public class Contatos {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private int id;

  @ManyToOne
  @JoinColumn(name = "id_pessoa", nullable = false)
  Pessoas pessoas;

  @Column(name = "telefone", length = 11, nullable = false)
  private String telefone;
  
  @Column(name = "endereco", length = 40, nullable = false)
  private String endereco;
  
  @Column(name = "email", length = 20, nullable = false)
  private String email;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public Pessoas getPessoas() {
    return pessoas;
  }

  public void setPessoas(Pessoas pessoas) {
    this.pessoas = pessoas;
  }

  public String getTelefone() {
    return telefone;
  }

  public void setTelefone(String telefone) {
    this.telefone = telefone;
  }

  public String getEndereco() {
    return endereco;
  }

  public void setEndereco(String endereco) {
    this.endereco = endereco;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }



}
