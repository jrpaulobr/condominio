package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import br.com.junior.condominio.models.Apartamentos;
import br.com.junior.condominio.models.Usuarios;
import br.com.junior.condominio.util.Manager;

public class UsuariosDAO {

	EntityManager manager = Manager.getManager();

	public void salvar(Usuarios alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();		
	}

	public void atualiza(Usuarios alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();		
	}

	public void remove(Usuarios alias) {
		manager.getTransaction().begin();
		 manager.remove(manager.merge(alias));
		manager.getTransaction().commit();		
		
	}

	@SuppressWarnings("unchecked")
	public List<Usuarios> lista() {
		Query query = manager.createQuery("SELECT p from Usuarios p");
		// seta dados
		List<Usuarios> list = query.getResultList();
		return list;
	}
	public Usuarios localiza(Usuarios alias) {
		return manager.find(Usuarios.class, alias.getId());
	}

}
