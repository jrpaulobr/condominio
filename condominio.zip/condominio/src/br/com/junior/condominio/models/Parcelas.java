package br.com.junior.condominio.models;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

import com.thoughtworks.xstream.converters.basic.DateConverter;

import br.com.caelum.vraptor.Convert;

@Entity
@Table(name = "parcelas")
public class Parcelas {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
		
	@ManyToOne
	@JoinColumn(name = "id_movimento", nullable = false)
	Movimento movimento;

	@Column(name = "parcela", nullable = false)
	private int parcela;
	
	@Temporal(javax.persistence.TemporalType.DATE)
	@Column(name="vencimento")
	@Convert(DateConverter.class)
	private Date vencimento;
	
	@Temporal(javax.persistence.TemporalType.DATE)
	@Column(name="pagamento")
	@Convert(DateConverter.class)
	private Date pagamento;
	
	@Column(name = "valor", precision = 19, scale = 2, columnDefinition="DECIMAL(19,2)", nullable = false)
	private BigDecimal valor;

	@Column(name = "situacao",length = 7, nullable = false)
	private String situacao;
	
	public Movimento getMovimento() {
		return movimento;
	}

	public void setMovimento(Movimento movimento) {
		this.movimento = movimento;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Movimento getMovimentocontabil() {
		return movimento;
	}

	public void setMovimentocontabil(Movimento movimento) {
		this.movimento = movimento;
	}

	public int getParcela() {
		return parcela;
	}

	public void setParcela(int parcela) {
		this.parcela = parcela;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public Date getVencimento() {
		return vencimento;
	}

	public void setVencimento(Date vencimento) {
		this.vencimento = vencimento;
	}

	public Date getPagamento() {
		return pagamento;
	}

	public void setPagamento(Date pagamento) {
		this.pagamento = pagamento;
	}
	
	

	
}
