package br.com.junior.condominio.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Manager {
	private static EntityManagerFactory factory = Persistence.createEntityManagerFactory("condominio");
	private static EntityManager manager;

	public static EntityManager getManager() {
		return manager;
	}
	
	public Manager() {
		manager = factory.createEntityManager();
	}

}
