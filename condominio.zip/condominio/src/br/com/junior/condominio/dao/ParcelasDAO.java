package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.junior.condominio.models.Parcelas;
import br.com.junior.condominio.util.Manager;

public class ParcelasDAO {	

	EntityManager manager = Manager.getManager();

	public void salvar(Parcelas alias) {	
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();
	}
 
	public void remove(Parcelas alias) {
		manager.getTransaction().begin();
		manager.remove(manager.merge(alias));
		manager.getTransaction().commit();

	}

	@SuppressWarnings("unchecked")
	public List<Parcelas> lista() {
		Query query = manager.createQuery("select a from Parcelas a");
		List<Parcelas> list = query.getResultList();
		
		return list;
	}
	
	public Parcelas localiza(Parcelas alias) {
		return manager.find(Parcelas.class, alias.getId());
	}

}
