package br.com.junior.condominio.Controller;


import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.UnidadesDAO;
import br.com.junior.condominio.models.Unidades;
import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class UnidadesController {
	private Result result;

	public UnidadesController(Result result) {
		this.result = result;
	}
	@Path("/unidades")
	public void cadastrar() {
		new Manager();
	}

	public void listar() {
		result.use(Results.json()).withoutRoot().from(new UnidadesDAO().lista()).serialize();
	}

	public void consultar(Unidades u) {
		result.use(Results.json()).withoutRoot().from(new UnidadesDAO().localiza(u)).serialize();

	}

	public void salvar(Unidades u) {
		try {
			new UnidadesDAO().salvar(u);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Unidades: " + ex);
		}

	}

	public void remover(Unidades u) {
		try {
			new UnidadesDAO().remove(u);
			result.use(Results.http()).body("Sucesso");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Unidades: " + ex);
		}

	}
}
