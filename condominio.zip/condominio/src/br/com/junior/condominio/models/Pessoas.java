package br.com.junior.condominio.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pessoas")
public class Pessoas {
	
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private int id;
  
  @Column(name = "tipo", length = 8, nullable = false)
  private String tipo;

  @Column(name = "nome", length = 40, nullable = false)
  private String nome;
  
  @Column(name = "cpfcnpj", length = 15, nullable = false)
  private String cpfcnpj;
  
  @Column(name = "situacao", length = 7, nullable = false)
  private String situacao;
  
  @Column(name = "rgie", length = 14, nullable = false)
  private String rgie	;
  
  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getCpfcnpj() {
    return cpfcnpj;
  }

  public void setCpfcnpj(String cpfcnpj) {
    this.cpfcnpj = cpfcnpj;
  }

  public String getSituacao() {
    return situacao;
  }

  public void setSituacao(String situacao) {
    this.situacao = situacao;
  }

  public String getRgie() {
    return rgie;
  }

  public void setRgie(String rgie) {
    this.rgie = rgie;
  }


}
