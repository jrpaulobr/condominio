package br.com.junior.condominio.teste;

import br.com.junior.condominio.dao.UnidadesDAO;
import br.com.junior.condominio.models.Unidades;

public class testeUnidades {

	static UnidadesDAO undao = new UnidadesDAO();
	static Unidades uni = new Unidades();
	public static void main(String[] args) {
		
		inserir();
		
	}
	private static void inserir(){
		uni.setId(1);
		uni.setDescricao("C");
		uni.setTipo("Bloco");
		undao.salvar(uni);
	}
		
}
