package br.com.junior.condominio.Controller;

import static br.com.caelum.vraptor.view.Results.json;

import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Patch;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.ContatoDAO;
import br.com.junior.condominio.models.Contatos;
import br.com.caelum.vraptor.view.Results;

@Resource
public class ContatosController {
	private Result result;

	public ContatosController(Result result) {
		this.result = result;
	}

	/**
	 *  atualiza Contatos
	 * @param alias
	 */
	public void atualizar(Contatos alias) {
		try {
			new ContatoDAO().atualiza(alias);
			result.use(Results.http()).body("Sucesso");
		} catch (RuntimeException e) {
			result.use(Results.http()).body("Erro ao Tentar Atualizar Contatos <br>" + "Erro: " + e);
		}
	}

	/**
	 *  remove Contatos
	 * @param alias
	 */
	public void remove(Contatos alias) {
		try {
			new ContatoDAO().remove(alias);
			result.use(Results.http()).body("Sucesso");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Contatos: " + ex);
		}

	}

	/**
	 *localiza Contatos especifica passado por id 
	 */	  
	@Get
	@Patch("/Contatos/localiza.json")
	public void localiza(Contatos alias) {
		result.use(json()).withoutRoot().from(new ContatoDAO().localiza(alias)).include("grupo").serialize();

	}

	public void teste() {

	}

	/**
	 * Lista todas as Contatos
	 */
	@Get
	@Patch("/Contatos/lista.json")
	public void lista() {
		result.use(json()).withoutRoot().from(new ContatoDAO().lista()).include("grupo").serialize();

	}

	/**
	 * Cadastrar Contatos
	 * 
	 * @param alias
	 */
	public void adiciona(Contatos alias) {
		try {
			new ContatoDAO().adiciona(alias);
			result.use(Results.http()).body("Sucesso");
		} catch (RuntimeException e) {
			result.use(Results.http())
					.body("Erro ao Cadastrar Contatos Verifique Se Todos Campos Estao Preenchidos de Forma Correta <br>"
							+ "Erro: " + e);
		}

	}

	/**
	 * Exibe o jsp para cadastrar 
	 * 
	 */
	public void cadastrar() {

	}

	// exibe o pagina para atualizar
	public void visualizar() {
		result.include("Contatos", new ContatoDAO().lista());
	}

	public void listaJSTL(){
	  result.include("Contatos", new ContatoDAO().lista());
	}
}
