package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.RateioDAO;

import br.com.junior.condominio.models.Rateio;

import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class RateioController {
	private Result result;

	public RateioController(Result result) {
		this.result = result;
	}
	@Path("/rateio")
	public void rateio() {
		//new Manager();
		// result.forwardTo("/WEB-INF/jsp/rateio/cadastrar.jsp");
	}
	@Path("/rateio/gerar")
	public void gerar() {
		//new Manager();
		// result.forwardTo("/WEB-INF/jsp/rateio/cadastrar.jsp");
	}
	public void listar() {
		new Manager();
		result.use(Results.json()).withoutRoot().from(new RateioDAO().lista());
	}

	public void consultar(Rateio a) {
		//result.use(Results.json()).withoutRoot().from(new RateioDAO().localiza(a)).serialize();
		new Manager();
		result.use(Results.json()).withoutRoot().from(new RateioDAO().localiza(a));
		
	}

	public void salvar(Rateio a) {
		try {
			new RateioDAO().salvar(a);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Rateio: " + ex);
		}

	}

	public void remove(Rateio a) {
		try {
			new RateioDAO().remove(a);
			// new RateioDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Rateio: " + ex);
		}

	}
}
