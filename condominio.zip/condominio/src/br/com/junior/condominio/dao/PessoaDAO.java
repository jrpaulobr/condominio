package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.junior.condominio.models.Pessoas;
import br.com.junior.condominio.models.Unidades;
import br.com.junior.condominio.util.Manager;

public class PessoaDAO {

	EntityManager manager = Manager.getManager();

	public void salvar(Pessoas alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();		
	}

	public void atualiza(Pessoas alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();		
	}

	public void remove(Pessoas alias) {
		manager.getTransaction().begin();
		 manager.remove(manager.merge(alias));
		manager.getTransaction().commit();		
		
	}

	@SuppressWarnings("unchecked")
	public List<Pessoas> lista() {
		Query query = manager.createQuery("SELECT p from Pessoas p");
		// seta dados
		List<Pessoas> list = query.getResultList();
		return list;
	}

	public Pessoas localiza(Pessoas alias) {
		return manager.find(Pessoas.class, alias.getId());
	}

}
