package br.com.junior.condominio.models;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "apartamentos")
public class Movimento {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
		
	@ManyToOne
	@JoinColumn(name = "id_caixa", nullable = false)
	Caixa caixa;

	@Column(name = "tipo",length = 7, nullable = false)
	private String tipo;
	
	@Column(name = "rateio",length = 3, nullable = false)
	private String rateio;
	
	@Column(name = "documento",length = 25, nullable = false)
	private String documento;
	
	@Column(name = "descricao",length = 60, nullable = false)
	private String descricao;
	
	@Column(name = "obsrevacao",length = 255, nullable = false)
	private String obsrevacao;
	
	@Column(name = "valor", precision = 19, scale = 2, columnDefinition="DECIMAL(19,2)", nullable = false)
	private BigDecimal valor;
	
	@Column(name = "parcelas", length = 3, nullable = false)
	private String parcelas;
	
	@Column(name = "fixo", length = 3, nullable = false)
	private String fixo;
	
	public String getFixo() {
		return fixo;
	}

	public void setFixo(String fixo) {
		this.fixo = fixo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Caixa getCaixa() {
		return caixa;
	}

	public void setCaixa(Caixa caixa) {
		this.caixa = caixa;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getObsrevacao() {
		return obsrevacao;
	}

	public void setObsrevacao(String obsrevacao) {
		this.obsrevacao = obsrevacao;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getRateio() {
		return rateio;
	}

	public void setRateio(String rateio) {
		this.rateio = rateio;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getParcelas() {
		return parcelas;
	}

	public void setParcelas(String parcelas) {
		this.parcelas = parcelas;
	}



}
