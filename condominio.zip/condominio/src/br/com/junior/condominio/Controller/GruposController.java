package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.GruposDAO;

import br.com.junior.condominio.models.Grupos;

import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class GruposController {
	private Result result;

	public GruposController(Result result) {
		this.result = result;
	}
	@Path("/grupos")
	public void cadastrar() {
		new Manager();
	}

	public void listar() {
		new Manager();
		result.use(Results.json()).withoutRoot().from(new GruposDAO().lista());
	}

	public void consultar(Grupos a) {
		//result.use(Results.json()).withoutRoot().from(new GruposDAO().localiza(a)).serialize();
		new Manager();
		result.use(Results.json()).withoutRoot().from(new GruposDAO().localiza(a));
		
	}

	public void salvar(Grupos a) {
		try {
			new GruposDAO().salvar(a);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Grupos: " + ex);
		}

	}

	public void remove(Grupos a) {
		try {
			new GruposDAO().remove(a);
			// new GruposDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Grupos: " + ex);
		}

	}
}
