package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.MovCaixaDAO;

import br.com.junior.condominio.models.MovCaixa;

import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class MovCaixaController {
	private Result result;

	public MovCaixaController(Result result) {
		this.result = result;
	}
	@Path("/movcaixa")
	public void cadastrar() {
		//new Manager();
		// result.forwardTo("/WEB-INF/jsp/movcaixa/cadastrar.jsp");
	}

	public void listar() {
		new Manager();
		result.use(Results.json()).withoutRoot().from(new MovCaixaDAO().lista());
	}

	public void consultar(MovCaixa a) {
		//result.use(Results.json()).withoutRoot().from(new MovCaixaDAO().localiza(a)).serialize();
		new Manager();
		result.use(Results.json()).withoutRoot().from(new MovCaixaDAO().localiza(a));
		
	}

	public void salvar(MovCaixa a) {
		try {
			new MovCaixaDAO().salvar(a);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar MovCaixa: " + ex);
		}

	}

	public void remove(MovCaixa a) {
		try {
			new MovCaixaDAO().remove(a);
			// new MovCaixaDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar MovCaixa: " + ex);
		}

	}
}
