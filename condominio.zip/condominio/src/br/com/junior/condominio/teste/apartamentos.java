package br.com.junior.condominio.teste;

import br.com.junior.condominio.dao.ApartamentoDAO;
import br.com.junior.condominio.models.Apartamentos;
import br.com.junior.condominio.models.Unidades;

public class apartamentos {

	static ApartamentoDAO apdao = new ApartamentoDAO();
	static Apartamentos ape = new Apartamentos();
	static Unidades uni = new Unidades();
	public static void main(String[] args) {
		
		inserirApe();
		
	}
	private static void inserirApe(){
		ape.setId(4);
		ape.setIsento_taxa("N�o Isento");
		ape.setNumero(501);
		uni.setId(33);
		uni.setDescricao("pitangas");
		uni.setTipo("Pr�dio");
		ape.setUnidades(uni);
		System.out.println(ape.getId());
		apdao.salvar(ape);
	}
		
}
