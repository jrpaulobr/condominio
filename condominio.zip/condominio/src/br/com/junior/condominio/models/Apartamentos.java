package br.com.junior.condominio.models;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "apartamentos")
public class Apartamentos {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
		
	@ManyToOne
	@JoinColumn(name = "id_unidade", nullable = false)
	Unidades unidades;
	
	@ManyToOne
	@JoinColumn(name = "id_morador", nullable = false)
	Pessoas pessoaMorador;
	
	@ManyToOne
	@JoinColumn(name = "id_proprietario", nullable = false)
	Pessoas pessoaProprietario;

	@Column(name = "numero", nullable = false)
	private int numero;
	
	@Column(name = "isento_taxa", length = 3, nullable = false)
	private String isento_taxa;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Unidades getUnidades() {
		return unidades;
	}

	public void setUnidades(Unidades unidades) {
		this.unidades = unidades;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getIsento_taxa() {
		return isento_taxa;
	}

	public void setIsento_taxa(String isento_taxa) {
		this.isento_taxa = isento_taxa;
	}

}
