package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.junior.condominio.models.Unidades;
import br.com.junior.condominio.util.Manager;

public class UnidadesDAO {

	EntityManager manager = Manager.getManager();
	
	public void salvar(Unidades alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();
	}

	public void remove(Unidades alias) {
		manager.getTransaction().begin();
		manager.remove(manager.merge(alias));
		manager.getTransaction().commit();
	}

	@SuppressWarnings("unchecked")
	public List<Unidades> lista() {
		Query query = manager.createQuery("SELECT alias from Unidades alias");
		// seta dados
		List<Unidades> list = query.getResultList();
		return list;
	}

	public Unidades localiza(Unidades alias) {
		return manager.find(Unidades.class, alias.getId());
	}

}
