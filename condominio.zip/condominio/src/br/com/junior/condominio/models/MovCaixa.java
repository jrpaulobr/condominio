package br.com.junior.condominio.models;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

import com.thoughtworks.xstream.converters.basic.DateConverter;

import br.com.caelum.vraptor.Convert;

@Entity
@Table(name = "movcaixa")
public class MovCaixa {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
		
	@ManyToOne
	@JoinColumn(name = "id_caixa", nullable = false)
	Caixa caixa;
	
	@Temporal(javax.persistence.TemporalType.DATE)
	@Column(name="data")
	@Convert(DateConverter.class)
	private Date data;

	  @Column(name = "valor", precision = 19, scale = 2, columnDefinition="DECIMAL(19,2)", nullable = false)
	  private BigDecimal valor;
	
	@Column(name = "descricao", length = 30, nullable = false)
	private String descricao;

	@Column(name = "tipo", length = 30, nullable = false)
	private String tipo;
	
	public Caixa getCaixa() {
		return caixa;
	}

	public void setCaixa(Caixa caixa) {
		this.caixa = caixa;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
