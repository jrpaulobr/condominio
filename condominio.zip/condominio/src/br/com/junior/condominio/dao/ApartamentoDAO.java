package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.junior.condominio.models.Apartamentos;
import br.com.junior.condominio.util.Manager;

public class ApartamentoDAO {	

	EntityManager manager = Manager.getManager();

	public void salvar(Apartamentos alias) {	
		
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();
	
	}
	
 
	public void remove(Apartamentos alias) {
		
		manager.getTransaction().begin();
		manager.remove(manager.merge(alias));
		manager.getTransaction().commit();

	}

	@SuppressWarnings("unchecked")
	public List<Apartamentos> lista() {
		Query query = manager.createQuery("select a from Apartamentos a");
		List<Apartamentos> list = query.getResultList();
		
		return list;
	}
	
	public Apartamentos localiza(Apartamentos alias) {
		return manager.find(Apartamentos.class, alias.getId());
	}

}
