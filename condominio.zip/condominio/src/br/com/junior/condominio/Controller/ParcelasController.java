package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.ParcelasDAO;

import br.com.junior.condominio.models.Parcelas;

import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class ParcelasController {
	private Result result;

	public ParcelasController(Result result) {
		this.result = result;
	}
	@Path("/parcelas")
	public void cadastrar() {
		//new Manager();
		// result.forwardTo("/WEB-INF/jsp/parcelas/cadastrar.jsp");
	}

	public void listar() {
		new Manager();
		result.use(Results.json()).withoutRoot().from(new ParcelasDAO().lista());
	}

	public void consultar(Parcelas a) {
		//result.use(Results.json()).withoutRoot().from(new ParcelasDAO().localiza(a)).serialize();
		new Manager();
		result.use(Results.json()).withoutRoot().from(new ParcelasDAO().localiza(a));
		
	}

	public void salvar(Parcelas a) {
		try {
			new ParcelasDAO().salvar(a);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Parcelas: " + ex);
		}

	}

	public void remove(Parcelas a) {
		try {
			new ParcelasDAO().remove(a);
			// new ParcelasDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Parcelas: " + ex);
		}

	}
}
