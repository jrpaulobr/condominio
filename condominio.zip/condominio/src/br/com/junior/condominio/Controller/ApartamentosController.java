package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.ApartamentoDAO;

import br.com.junior.condominio.models.Apartamentos;

import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class ApartamentosController {
	private Result result;

	public ApartamentosController(Result result) {
		this.result = result;
	}
	@Path("/apartamentos")
	public void cadastrar() {
		//new Manager();
		// result.forwardTo("/WEB-INF/jsp/apartamentos/cadastrar.jsp");
	}
	@Path("/apartamentos/listar")
	public void listar() {
		new Manager();
		result.use(Results.json()).withoutRoot().from(new ApartamentoDAO().lista()).include("unidades").serialize();
	}
	@Path("/apartamentos/consultar")
	public void consultar(Apartamentos a) {
		//result.use(Results.json()).withoutRoot().from(new ApartamentoDAO().localiza(a)).serialize();
		new Manager();
		result.use(Results.json()).withoutRoot().from(new ApartamentoDAO().localiza(a)).include("unidades").serialize();
		
	}
	@Path("/apartamentos/salvar")
	public void salvar(Apartamentos a) {
		try {
			new ApartamentoDAO().salvar(a);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Apartamentos: " + ex);
		}

	}

	public void remove(Apartamentos a) {
		try {
			new ApartamentoDAO().remove(a);
			// new ApartamentoDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Apartamentos: " + ex);
		}

	}
}
