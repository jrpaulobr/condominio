package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import br.com.junior.condominio.models.Caixa;
import br.com.junior.condominio.models.Caixa;
import br.com.junior.condominio.util.Manager;

public class CaixaDAO {
	
	EntityManager manager = Manager.getManager();

	public void adiciona(Caixa alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();	
	}


	public void remove(Caixa alias) {
		manager.getTransaction().begin();
		 manager.remove(manager.merge(alias));
		manager.getTransaction().commit();		
		
	}

	@SuppressWarnings("unchecked")
	public List<Caixa> lista() {
		Query query = manager.createQuery("SELECT alias from Caixa alias");
		// seta dados
		List<Caixa> list = query.getResultList();
		return list;
	}

	public Caixa localiza(Caixa alias) {
		return manager.find(Caixa.class, alias.getId());
	}

}
