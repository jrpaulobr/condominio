package br.com.junior.condominio.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.junior.condominio.models.Rateio;
import br.com.junior.condominio.util.Manager;

public class RateioDAO {

	EntityManager manager = Manager.getManager();
	
	public void salvar(Rateio alias) {
		manager.getTransaction().begin();
		manager.merge(alias);
		manager.getTransaction().commit();
	}

	public void remove(Rateio alias) {
		manager.getTransaction().begin();
		manager.remove(manager.merge(alias));
		manager.getTransaction().commit();
	}

	@SuppressWarnings("unchecked")
	public List<Rateio> lista() {
		Query query = manager.createQuery("SELECT alias from Rateio alias");
		// seta dados
		List<Rateio> list = query.getResultList();
		return list;
	}

	public Rateio localiza(Rateio alias) {
		return manager.find(Rateio.class, alias.getId());
	}

}
