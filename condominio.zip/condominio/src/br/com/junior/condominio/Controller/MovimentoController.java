package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.MovimentoDAO;

import br.com.junior.condominio.models.Movimento;

import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class MovimentoController {
	private Result result;

	public MovimentoController(Result result) {
		this.result = result;
	}
	@Path("/movimento")
	public void cadastrar() {
		new Manager();
		// result.forwardTo("/WEB-INF/jsp/apartamentos/cadastrar.jsp");
	}

	public void listar() {
		new Manager();
		result.use(Results.json()).withoutRoot().from(new MovimentoDAO().lista()).include("caixa").serialize();
	}

	public void consultar(Movimento alias) {
		//result.use(Results.json()).withoutRoot().from(new MovimentoDAO().localiza(alias)).serialize();
		new Manager();
		result.use(Results.json()).withoutRoot().from(new MovimentoDAO().localiza(alias)).include("caixa").serialize();
		
	}

	public void salvar(Movimento alias) {
		try {
			new MovimentoDAO().salvar(alias);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Movimento: " + ex);
		}

	}

	public void remove(Movimento alias) {
		try {
			new MovimentoDAO().remove(alias);
			// new MovimentoDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Movimento: " + ex);
		}

	}
}
