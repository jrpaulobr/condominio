package br.com.junior.condominio.models;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

import com.thoughtworks.xstream.converters.basic.DateConverter;

import br.com.caelum.vraptor.Convert;

@Entity
@Table(name = "rateio")
public class Rateio {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
		
	@ManyToOne
	@JoinColumn(name = "id_movimento", nullable = false)
	Movimento movimento;
	
	@ManyToOne
	@JoinColumn(name = "apartamentos", nullable = false)
	Apartamentos apartamentos;

	@Column(name = "valor", precision = 19, scale = 2, columnDefinition="DECIMAL(19,2)", nullable = false)
	private BigDecimal valor;
	
	@Column(name = "percent", length = 4, nullable = false)
	private String percent;

	@Column(name = "mes", length = 2, nullable = false)
	private String mes;
	
	@Column(name = "ano", length = 3, nullable = false)
	private String ano;

	@Temporal(javax.persistence.TemporalType.DATE)
	@Column(name="data_cobranca")
	@Convert(DateConverter.class)
	private Date data_cobranca;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Movimento getMovimento() {
		return movimento;
	}

	public void setMovimento(Movimento movimento) {
		this.movimento = movimento;
	}

	public Apartamentos getApartamentos() {
		return apartamentos;
	}

	public void setApartamentos(Apartamentos apartamentos) {
		this.apartamentos = apartamentos;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getPercent() {
		return percent;
	}

	public void setPercent(String percent) {
		this.percent = percent;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public Date getData_cobranca() {
		return data_cobranca;
	}

	public void setData_cobranca(Date data_cobranca) {
		this.data_cobranca = data_cobranca;
	}

}
