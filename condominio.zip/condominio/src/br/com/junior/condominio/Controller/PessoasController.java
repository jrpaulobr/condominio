package br.com.junior.condominio.Controller;

import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Resource;
import br.com.caelum.vraptor.Result;
import br.com.junior.condominio.dao.PessoaDAO;
import br.com.junior.condominio.models.Pessoas;
import br.com.junior.condominio.util.Manager;
import br.com.caelum.vraptor.view.Results;

@Resource
public class PessoasController {
	private Result result;

	public PessoasController(Result result) {
		this.result = result;
	}
	@Path("/pessoas")	
	public void cadastrar() {
		new Manager();
	}

	public void listar() {
		new Manager();
	}

	public void consultar(Pessoas alias) {
		result.use(Results.json()).withoutRoot().from(new PessoaDAO().localiza(alias)).serialize();
		
	}

	public void salvar(Pessoas alias) {
		try {
			new PessoaDAO().salvar(alias);
			result.use(Results.http()).body("Sucesso!");
		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao salvar Pessoas: " + ex);
		}

	}

	public void remover(Pessoas a) {
		try {
			new PessoaDAO().remove(a);
			// new PessoaDAO().remove(alias);
			result.use(Results.http()).body("Deletado com Sucesso");

		} catch (Exception ex) {
			result.use(Results.http()).body("Erro ao Deletar Pessoas: " + ex);
		}

	}
}
